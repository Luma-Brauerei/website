"use strict";

const beers = [
    {
        name: "Helles",
        style: "Klassisch",
        image: "assets/images/beers/helles.webp",
        description: "Süffig, klar und ausgewogen. Ein unkompliziertes Bier für fast jeden Anlass.",
        hops: "Hallertauer Mittelfrüh, Tettnanger",
        malts: "Pilsner Malz, Wiener Malz",
        ibu: "ca. 20",
        abv: "ca. 5.0 %"
    },
    {
        name: "Brown Ale",
        style: "Malzig",
        image: "assets/images/beers/brown-ale.webp",
        description: "Rund, malzig und leicht karamellig. Vollmundig, aber nicht schwer.",
        hops: "East Kent Goldings, Fuggle",
        malts: "Pale Ale, Münchner, Crystal, Chocolate",
        ibu: "ca. 28",
        abv: "ca. 5.5 %"
    },
    {
        name: "Cold IPA",
        style: "Modern",
        image: "assets/images/beers/cold-ipa.webp",
        description: "Trocken, schlank und hopfenbetont. IPA-Aroma mit besonders klarem Finish.",
        hops: "Citra, Mosaic, Simcoe",
        malts: "Pilsner Malz, Reisflocken",
        ibu: "ca. 45",
        abv: "ca. 6.2 %"
    },
    {
        name: "Hazy IPA",
        style: "Fruchtig",
        image: "assets/images/beers/hazy-ipa.webp",
        description: "Saftig, weich und aromatisch. Viel Hopfenaroma, weniger kantige Bittere.",
        hops: "Citra, Mosaic, Galaxy",
        malts: "Pale Ale, Haferflocken, Weizenmalz",
        ibu: "ca. 35",
        abv: "ca. 6.0 %"
    }
];

let currentBeerIndex = 0;
let autoSlideTimer = null;

const beerImage = document.getElementById("beerImage");
const beerStyle = document.getElementById("beerStyle");
const beerName = document.getElementById("beerName");
const beerDescription = document.getElementById("beerDescription");
const beerHops = document.getElementById("beerHops");
const beerMalts = document.getElementById("beerMalts");
const beerIbu = document.getElementById("beerIbu");
const beerAbv = document.getElementById("beerAbv");
const beerDots = document.getElementById("beerDots");
const prevBeer = document.getElementById("prevBeer");
const nextBeer = document.getElementById("nextBeer");
const menuToggle = document.getElementById("menuToggle");
const mainNav = document.getElementById("mainNav");

const certificateModal = document.getElementById("certificateModal");
const certificateModalImage = document.getElementById("certificateModalImage");
const certificateModalTitle = document.getElementById("certificateModalTitle");
const certificateModalClose = document.getElementById("certificateModalClose");
const certificateModalBackdrop = document.getElementById("certificateModalBackdrop");
const certificateCards = document.querySelectorAll(".certificate-card");

function renderBeer(index) {
    if (!beerImage) return;

    const beer = beers[index];
    beerImage.style.backgroundImage = `linear-gradient(135deg, rgba(141,255,120,.12), rgba(255,79,163,.12)), url('${beer.image}')`;
    beerStyle.textContent = window.lumaTranslateDynamic ? window.lumaTranslateDynamic(beer.style) : beer.style;
    beerName.textContent = beer.name;
    beerDescription.textContent = window.lumaTranslateDynamic ? window.lumaTranslateDynamic(beer.description) : beer.description;
    beerHops.textContent = beer.hops;
    beerMalts.textContent = beer.malts;
    beerIbu.textContent = beer.ibu;
    beerAbv.textContent = beer.abv;

    beerDots?.querySelectorAll("button").forEach((button, dotIndex) => {
        button.classList.toggle("active", dotIndex === index);
    });
}

function goToBeer(index) {
    currentBeerIndex = (index + beers.length) % beers.length;
    renderBeer(currentBeerIndex);
    restartAutoSlide();
}

function createDots() {
    if (!beerDots) return;

    beerDots.innerHTML = "";

    beers.forEach((_, index) => {
        const button = document.createElement("button");
        button.type = "button";
        button.setAttribute("aria-label", `Bier ${index + 1} anzeigen`);
        button.addEventListener("click", () => goToBeer(index));
        beerDots.appendChild(button);
    });
}

function startAutoSlide() {
    if (!beerImage) return;
    autoSlideTimer = window.setInterval(() => goToBeer(currentBeerIndex + 1), 8000);
}

function restartAutoSlide() {
    if (autoSlideTimer) window.clearInterval(autoSlideTimer);
    startAutoSlide();
}

function openCertificate(src, title) {
    if (!certificateModal || !certificateModalImage || !certificateModalTitle) return;

    certificateModalImage.src = src;
    certificateModalImage.alt = title;
    certificateModalTitle.textContent = title;
    certificateModal.classList.add("open");
    certificateModal.setAttribute("aria-hidden", "false");
    document.body.classList.add("modal-open");
    certificateModalClose?.focus();
}

function closeCertificate() {
    if (!certificateModal || !certificateModalImage) return;

    certificateModal.classList.remove("open");
    certificateModal.setAttribute("aria-hidden", "true");
    certificateModalImage.src = "";
    document.body.classList.remove("modal-open");
}

prevBeer?.addEventListener("click", () => goToBeer(currentBeerIndex - 1));
nextBeer?.addEventListener("click", () => goToBeer(currentBeerIndex + 1));

menuToggle?.addEventListener("click", () => {
    const isOpen = mainNav?.classList.toggle("open") ?? false;
    menuToggle.setAttribute("aria-expanded", String(isOpen));
    menuToggle.setAttribute("aria-label", isOpen ? "Menü schliessen" : "Menü öffnen");
});

mainNav?.querySelectorAll("a").forEach((link) => {
    link.addEventListener("click", () => {
        mainNav.classList.remove("open");
        menuToggle?.setAttribute("aria-expanded", "false");
        menuToggle?.setAttribute("aria-label", "Menü öffnen");
    });
});

certificateCards.forEach((card) => {
    card.addEventListener("click", () => {
        openCertificate(card.dataset.certificate || "", card.dataset.title || "Zertifikat");
    });
});

certificateModalClose?.addEventListener("click", closeCertificate);
certificateModalBackdrop?.addEventListener("click", closeCertificate);

document.addEventListener("keydown", (event) => {
    if (event.key === "Escape" && certificateModal?.classList.contains("open")) {
        closeCertificate();
    }
});

createDots();
renderBeer(currentBeerIndex);
startAutoSlide();


/* Aktuelles-Slider */
const currentSlides = Array.from(document.querySelectorAll("[data-current-slide]"));
const currentDots = Array.from(document.querySelectorAll("[data-current-dot]"));
const prevCurrent = document.getElementById("prevCurrent");
const nextCurrent = document.getElementById("nextCurrent");
const currentSlider = document.getElementById("currentSlider");
let currentSlideIndex = 0;
let currentSlideTimer = null;

function renderCurrentSlide(index) {
    if (!currentSlides.length) return;

    currentSlideIndex = (index + currentSlides.length) % currentSlides.length;

    currentSlides.forEach((slide, slideIndex) => {
        const isActive = slideIndex === currentSlideIndex;
        slide.classList.toggle("active", isActive);
        slide.setAttribute("aria-hidden", String(!isActive));

        if (!isActive) {
            slide.querySelectorAll("video").forEach((video) => video.pause());
        }
    });

    currentDots.forEach((dot, dotIndex) => {
        dot.classList.toggle("active", dotIndex === currentSlideIndex);
        dot.setAttribute("aria-current", dotIndex === currentSlideIndex ? "true" : "false");
    });
}

function startCurrentSlider() {
    if (currentSlides.length < 2) return;
    currentSlideTimer = window.setInterval(() => renderCurrentSlide(currentSlideIndex + 1), 8000);
}

function restartCurrentSlider() {
    if (currentSlideTimer) window.clearInterval(currentSlideTimer);
    startCurrentSlider();
}

function goToCurrentSlide(index) {
    renderCurrentSlide(index);
    restartCurrentSlider();
}

prevCurrent?.addEventListener("click", () => goToCurrentSlide(currentSlideIndex - 1));
nextCurrent?.addEventListener("click", () => goToCurrentSlide(currentSlideIndex + 1));
currentDots.forEach((dot) => {
    dot.addEventListener("click", () => goToCurrentSlide(Number(dot.dataset.currentDot || 0)));
});

currentSlider?.addEventListener("mouseenter", () => {
    if (currentSlideTimer) window.clearInterval(currentSlideTimer);
});
currentSlider?.addEventListener("mouseleave", restartCurrentSlider);
currentSlider?.addEventListener("focusin", () => {
    if (currentSlideTimer) window.clearInterval(currentSlideTimer);
});
currentSlider?.addEventListener("focusout", restartCurrentSlider);

renderCurrentSlide(0);
startCurrentSlider();

/* Bilingual interface: the original German copy stays in the HTML. */
(function () {
 const controls = document.querySelectorAll('[data-lang]');
 const elements = Array.from(document.querySelectorAll('[data-en]'));
 elements.forEach(el => { el.dataset.de = el.textContent.trim(); });
 const dynamic = {
  'Klassisch':'Classic','Malzig':'Malty','Modern':'Modern','Fruchtig':'Fruity',
  'Süffig, klar und ausgewogen. Ein unkompliziertes Bier für fast jeden Anlass.':'Smooth, clear and balanced. An easy-drinking beer for almost any occasion.',
  'Rund, malzig und leicht karamellig. Vollmundig, aber nicht schwer.':'Round, malty and gently caramel-like. Full-bodied without being heavy.',
  'Trocken, schlank und hopfenbetont. IPA-Aroma mit besonders klarem Finish.':'Dry, crisp and hop-forward. IPA aromas with an especially clean finish.',
  'Saftig, weich und aromatisch. Viel Hopfenaroma, weniger kantige Bittere.':'Juicy, soft and aromatic. Plenty of hop character with a gentler bitterness.'
 };
 let lang = 'de';
 function applyLanguage(next) {
  lang = next === 'en' ? 'en' : 'de';
  document.documentElement.lang = lang === 'en' ? 'en' : 'de-CH';
  elements.forEach(el => {el.textContent = lang === 'en' ? el.dataset.en : el.dataset.de;});
  controls.forEach(b => { b.setAttribute('aria-pressed', String(b.dataset.lang === lang)); });
  document.title = lang === 'en' ? 'LUMA Brewery Aarau – Craft Beer & Beer for Events' : 'LUMA Brauerei Aarau – Craft Beer & Bier für Feste';
  document.querySelector('meta[name="description"]')?.setAttribute('content', lang === 'en' ? 'LUMA craft brewery in Aarau: independently brewed Helles, Brown Ale, IPAs and kegs for events.' : 'LUMA Brauerei in Aarau: handwerklich gebrautes Craft Beer, Helles, Brown Ale, IPAs, Kegs und Ausschanklösungen für Feste und Events.');
  if (typeof renderBeer === 'function') renderBeer(currentBeerIndex);
  try { localStorage.setItem('luma-language',lang); } catch(e) {}
 }
 controls.forEach(b => b.addEventListener('click',()=>applyLanguage(b.dataset.lang)));
 try {applyLanguage(localStorage.getItem('luma-language') || 'de');} catch(e) {applyLanguage('de');}
 window.lumaLanguage = () => lang;
 window.lumaTranslateDynamic = text => lang === 'en' ? (dynamic[text] || text) : text;
})();
